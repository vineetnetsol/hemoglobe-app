/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React, { useEffect } from 'react';
import { View,Text } from 'react-native';
import Navigation from './src/routes';

const App=(props)=>{
    
  useEffect(()=>{
      
    
  },[])
  return(
      <Navigation/>
  )
}


export default App;
