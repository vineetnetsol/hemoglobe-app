const fonts = {
    LIGHT: "Poppins-Light",
    REGULAR: "Poppins-Regular",
    MEDIUM: "Poppins-Medium",
    SEMI_BOLD: "Poppins-SemiBold",
    BOLD: "Poppins-Bold",
    EXTRA_BOLD: "Poppins-ExtraBold",
    BLACK: "Poppins-Black",
    MONTESERRAT_MEDIUM: 'Poppins-Medium',
  
  };
  
  export default fonts;
  