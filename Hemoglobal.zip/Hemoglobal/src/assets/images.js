const Images = {
  landingscreen: {
    step1: require('./images/landingscreen.png'),
    donate: require('./images/donor.png'),
    drop: require('./images/dropa.png'),
    finddonor: require('./images/finddonor.png'),
    donationdrive: require('./images/donationdrive.png'),
    icCross: require('./images/icCross.png'),
    phone: require('./images/phone.png'),
    email: require('./images/email.png'),
    glass: require('./images/glass.png'),
  },
};
export default Images;
