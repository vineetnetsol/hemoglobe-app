import {View} from 'react-native';
import React from 'react';
import {SkypeIndicator} from 'react-native-indicators';
const SpinnerUi = props => {
  const indicatorColor = '#DE0A1E';

  return (
    <View
      style={{
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        left: 0,
        top: 0,
        bottom: 0,
        right: 0,
        flex: 1,
        zIndex: 9999,
        backgroundColor: 'rgba(255, 255, 255, 0.0)',
      }}>
      <SkypeIndicator
        color={indicatorColor}
        interaction={false}
        size={50}
        animating={props.spinner}
      />
    </View>
  );
};

export default SpinnerUi;
