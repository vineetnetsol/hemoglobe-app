import axios from 'axios';

const CONTENT_TYPE = 'application/json;';

export const apiWithHeader = baseUrl =>
  axios.create({
    baseURL: 'https://jsonplaceholder.typicode.com/todos/1',
    headers: {
      //   'Content-Type': CONTENT_TYPE,
      //   'x-api-key': 'gxbFjToCsHaHeD9s6LjpH2SJVmAUX8go6nNmvvfQ',
    },
  });
