import React from 'react';
import {View, TouchableOpacity, Image} from 'react-native';
import Images from '../assets/images';

const CrossButton = props => {
  const isTint = props.isTint == 'undefined' ? false : props.isTint;
  return (
    <View
      style={{
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginTop: props.isNoMarginTop == null ? 10 : 0,
      }}>
      <TouchableOpacity hitSlop={props.hitSlop ?? {}} onPress={props.onPress}>
        <Image
          source={props.image ?? Images.landingscreen.icCross}
          style={{
            tintColor: !isTint ? 'rgb(159,164,176)' : 'rgb(255,255,255)',
            height: 15,
            width: 15,
          }}
        />
      </TouchableOpacity>
    </View>
  );
};
export default CrossButton;
