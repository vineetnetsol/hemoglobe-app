import moment from 'moment';
import React, {useEffect, useState} from 'react';
import Moment from 'react-moment';
import {
  Alert,
  Image,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import DatePicker from 'react-native-date-picker';
import fonts from '../../assets/fonts';
import {styles} from './styles';
import CheckBox from '@react-native-community/checkbox';
import DropDownPicker from 'react-native-dropdown-picker';
import SelectDropdown from 'react-native-select-dropdown';
import axios, {apiWithHeader} from '../../components/axios';
import DeviceInfo from 'react-native-device-info';
import {useToast} from 'native-base';
import {
  Urlforcities,
  Urlforregisterdonor,
  UrlforStates,
} from '../../services/apiconfig';
import {apiKey} from '../../components/constants';
import SpinnerUi from '../../components/SpinnerUi';
import Images from '../../assets/images';
const cities = ['Egypt', 'Canada', 'Australia', 'Ireland'];
const Homepage = ({navigation, route}) => {
  const toast = useToast();
  const dateToFormat = '1976-04-19T12:59-0500';
  const date = new Date();
  const [name, setName] = useState('');
  const [male, setMale] = useState();
  const [gendertext, setGenderText] = useState('');
  const [female, setFemale] = useState();
  const [others, setOthers] = useState();
  const [ABpos, setAbpos] = useState(false);
  const [ABneg, setAbneg] = useState(false);
  const [Apos, setApos] = useState(false);
  const [Bpos, setBpos] = useState(false);
  const [Aneg, setAneg] = useState(false);
  const [Bneg, setBneg] = useState(false);
  const [Opos, setOpos] = useState(false);
  const [Oneg, setOneg] = useState(false);
  const [dob, setDob] = useState(date);
  const [open, setOpen] = useState(false);
  const [phoneNo, setPhoneNo] = useState('');
  const [Address, setAddress] = useState('');
  const [email, setEmail] = useState('');
  const [contactMobile, setContactMobile] = useState(false);
  const [contactEmail, setContactEmail] = useState(false);
  const [contactSms, setContactSms] = useState(false);
  const [citiesdata, setCitiesData] = useState([]);
  const [statesdata, setStatesData] = useState([]);
  const [statesdataObj, setstatesdataObj] = useState([]);
  const [citiesdataObj, setCitiesdataObj] = useState([]);
  const [selectedStatename, setSelectedStatename] = useState('');
  const [selectedCityname, setSelectedCityname] = useState('');
  const [bloodgrouptext, setBloodgrouptext] = useState('');
  const [anydisease, setAnydisease] = useState(false);
  const [nodisease, setNodisease] = useState(false);
  const [selectedEventid, setSelectedEventId] = useState('');
  const [loadingIndicator, setLoadingIndicator] = useState(false);
  useEffect(() => {
    getStates();
  }, []);

  const getStates = async () => {
    setLoadingIndicator(true);
    fetch(UrlforStates, {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
      },
    })
      .then(response => response.json())
      .then(json => {
        const localList = json;
        const array1 = JSON.stringify(localList.Items);
        const temparr = [];
        const Obj = JSON.parse(array1);
        setstatesdataObj(Obj);
        Obj.forEach(element => {
          temparr.push(element.name);
        });
        setStatesData(temparr);
        setLoadingIndicator(false);
      })
      .catch(error => {
        console.error(error);
        setLoadingIndicator(false);
      });
  };
  const getCities = async id => {
    setLoadingIndicator(true);
    fetch(Urlforcities + id, {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
      },
    })
      .then(response => response.json())
      .then(json => {
        // alert(JSON.stringify(json));
        const localList = json;
        const array1 = JSON.stringify(localList.Items);
        const temparr = [];

        const Obj = JSON.parse(array1);

        setCitiesdataObj(Obj);
        Obj.forEach(element => {
          temparr.push(element.city);
        });

        setCitiesData(temparr);
        setLoadingIndicator(false);
      })
      .catch(error => {
        console.error(error);
        setLoadingIndicator(false);
      });
  };
  const Registerasdonor = () => {
    setLoadingIndicator(true);
    const arrayofcontact = [];
    if (contactMobile) {
      arrayofcontact.push('m');
    } else if (contactSms) {
      arrayofcontact.push('s');
    } else if (contactEmail) {
      arrayofcontact.push('e');
    }

    fetch(Urlforregisterdonor, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
      },
      body: JSON.stringify({
        gender: gendertext,
        name: name,
        dob: moment(dob).format('YYYY-MM-DD'),
        blood_group: bloodgrouptext,
        disease: anydisease ? 1 : 0,
        city: selectedCityname,
        state: selectedStatename,
        email: email,
        phone: phoneNo,
        device_token: 'not available',
        address: Address,
        contact_mode: ['m'],
        contact_directly: 0,
        contact_disturbance_time: 0,
        event_id: route?.params?.event_id
          ? route?.params?.event_id
          : route?.params?.event_id,
      }),
    })
      .then(response => response.json())
      .then(json => {
        const data = JSON.stringify(json);
        const Obj = JSON.parse(data);
        if (!Obj.status) {
          alert(Obj.message);
          setLoadingIndicator(false);
        } else {
          setName('');
          setPhoneNo('');
          setAddress('');
          setMale(false);
          setFemale(false);
          setOthers(false);
          setAbneg(false);
          setAbpos(false);
          setApos(false);
          setAneg(false);
          setBneg(false);
          setBpos(false);
          setOneg(false);
          setOpos(false);
          setBneg(false);
          setBpos(false);
          setAnydisease(false);
          setNodisease(false);
          setAddress('');
          setEmail('');
          setSelectedCityname(false);
          setSelectedStatename(false);
          if (route?.params?.event_id) {
            alert(
              'Thank you!! Congratulations, you are now registered successfully for selected Camp on the Hemoglobe.',
            );
          } else {
            alert(
              'Thank you!! Congratulations, you are now registered successfully on the Hemoglobe. Please check out our Blood donation drives near you, so you can contribute.',
            );
          }
          setLoadingIndicator(false);
        }
      })
      .catch(error => {
        setLoadingIndicator(false);
        console.log(error);
      });
  };
  const bottomButtonView = (text, top, desc, nav) => {
    return (
      <View style={{marginTop: 30}}>
        <TouchableOpacity
          onPress={() => {
            Registerasdonor();
          }}
          style={{alignSelf: 'center'}}>
          <View style={styles.buttonContainer}>
            <Text style={styles.buttontextStyle}>{'Register as a Donor'}</Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  const TextandinputView = (text, value) => {
    return (
      <View style={{marginTop: 20}}>
        <Text
          style={{fontSize: 14, fontFamily: fonts.SEMI_BOLD, color: 'white'}}>
          {text}
        </Text>
        <TextInput
          value={value}
          style={{
            backgroundColor: 'white',
            borderRadius: 10,
            height: 35,
            marginTop: 12,
            padding: 10,
            color: '#EE848E',
          }}></TextInput>
      </View>
    );
  };

  const dateandtextView = text => {
    return (
      <View style={{marginTop: 30}}>
        <Text
          style={{fontSize: 18, fontFamily: fonts.MEDIUM, color: '#DE0A1E'}}>
          {text}
        </Text>
        <TouchableOpacity onPress={() => setOpen(true)}>
          <View
            style={{
              backgroundColor: 'white',
              borderRadius: 20,
              height: 50,
              marginTop: 12,
              justifyContent: 'center',
              padding: 10,
              color: '#EE848E',
            }}>
            <Text style={{color: '#EE848E', fontSize: 16}}>
              {moment(dob).format('YYYY-MM-DD')}
            </Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  };
  const textandcheckboxView = text => {
    return (
      <View style={{marginTop: 30}}>
        <Text
          style={{fontSize: 18, fontFamily: fonts.MEDIUM, color: '#DE0A1E'}}>
          {text}
        </Text>
        <View style={{flexDirection: 'row', marginTop: 12}}>
          <View style={{flexDirection: 'row', flex: 0.7}}>
            <CheckBox
              value={male}
              onValueChange={() => {
                setMale(true);
                setGenderText('m');
                setFemale(false);
                setOthers(false);
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text
              style={{
                marginLeft: 10,
                color: '#DE0A1E',
                fontSize: 15,
                alignSelf: 'center',
              }}>
              Male
            </Text>
          </View>
          <View style={{flexDirection: 'row', flex: 0.7}}>
            <CheckBox
              value={female}
              onValueChange={() => {
                setGenderText('f');
                setMale(false);
                setFemale(true);
                setOthers(false);
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text
              style={{
                marginLeft: 10,
                color: '#DE0A1E',
                fontSize: 15,
                alignSelf: 'center',
              }}>
              Female
            </Text>
          </View>
          <View style={{flexDirection: 'row', marginLeft: 25}}>
            <CheckBox
              value={others}
              onValueChange={() => {
                setMale(false);
                setGenderText('o');
                setFemale(false);
                setOthers(true);
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text
              style={{
                marginLeft: 10,
                color: '#DE0A1E',
                fontSize: 15,
                alignSelf: 'center',
              }}>
              Others
            </Text>
          </View>
        </View>
      </View>
    );
  };
  const CitiesView = () => {
    return (
      <View
        style={{
          marginTop: 30,
          flexDirection: 'row',
          justifyContent: 'space-between',
        }}>
        <View>
          <Text
            style={{fontSize: 18, fontFamily: fonts.MEDIUM, color: '#DE0A1E'}}>
            {'State'}
          </Text>
          <View style={{}}></View>
          <SelectDropdown
            buttonStyle={{
              marginTop: 12,

              borderRadius: 15,
              backgroundColor: 'white',
              height: 50,
              width: 150,
            }}
            dropdownStyle={{borderRadius: 15, height: 200}}
            onSelect={m => {
              statesdataObj.map(j => {
                if (j.name == m) {
                  setSelectedStatename(j.name);
                  getCities(j.id);
                  return;
                }
              });
            }}
            buttonTextStyle={{color: '#EE848E'}}
            data={statesdata}
            rowStyle={{height: 35}}
            rowTextStyle={{color: '#EE848E', fontSize: 16}}
            defaultButtonText={'State'}
          />
        </View>
        <View>
          <Text
            style={{fontSize: 18, fontFamily: fonts.MEDIUM, color: '#DE0A1E'}}>
            {'City'}
          </Text>
          <View style={{}}></View>
          <SelectDropdown
            buttonStyle={{
              marginTop: 12,

              borderRadius: 15,
              backgroundColor: 'white',
              height: 50,
              width: 150,
            }}
            dropdownStyle={{borderRadius: 15, height: 200}}
            onSelect={m => {
              citiesdataObj.map(j => {
                if (j.city == m) {
                  setSelectedCityname(j.city);
                  return;
                }
              });
            }}
            buttonTextStyle={{color: '#EE848E'}}
            rowTextStyle={{color: '#EE848E', fontSize: 16}}
            data={citiesdata}
            rowStyle={{height: 35}}
            defaultButtonText={'City'}
          />
        </View>
      </View>
    );
  };
  const NameView = () => {
    return (
      <View style={{marginTop: 10}}>
        <Text
          style={{fontSize: 18, fontFamily: fonts.MEDIUM, color: '#DE0A1E'}}>
          {'Full Name'}
        </Text>
        <TextInput
          onChangeText={text => setName(text)}
          value={name}
          placeholder={'Enter Full Name'}
          placeholderTextColor={'#EE848E'}
          style={{
            backgroundColor: 'white',
            borderRadius: 20,
            fontSize: 16,
            height: 50,
            marginTop: 8,
            padding: 10,
            color: '#EE848E',
          }}></TextInput>
      </View>
    );
  };
  const PhoneNumberView = () => {
    return (
      <View style={{marginTop: 30}}>
        <Text
          style={{fontSize: 18, fontFamily: fonts.MEDIUM, color: '#DE0A1E'}}>
          {'Mobile No'}
        </Text>
        <TextInput
          onChangeText={text => setPhoneNo(text)}
          value={phoneNo}
          placeholder={'Enter Mobile Number'}
          placeholderTextColor={'#EE848E'}
          style={{
            backgroundColor: 'white',
            borderRadius: 20,
            height: 50,
            fontSize: 16,
            marginTop: 12,
            padding: 10,
            color: '#EE848E',
          }}></TextInput>
      </View>
    );
  };
  const EmailView = () => {
    return (
      <View style={{marginTop: 30}}>
        <Text
          style={{fontSize: 18, fontFamily: fonts.MEDIUM, color: '#DE0A1E'}}>
          {'Email Address'}
        </Text>
        <TextInput
          onChangeText={text => setEmail(text)}
          value={email}
          placeholder={'Enter Email Address'}
          placeholderTextColor={'#EE848E'}
          style={{
            backgroundColor: 'white',
            borderRadius: 20,
            height: 50,
            fontSize: 16,
            marginTop: 12,
            padding: 10,
            color: '#EE848E',
          }}></TextInput>
      </View>
    );
  };
  const addressView = () => {
    return (
      <View style={{marginTop: 30}}>
        <Text
          style={{fontSize: 18, fontFamily: fonts.MEDIUM, color: '#DE0A1E'}}>
          {'Full Address'}
        </Text>
        <TextInput
          onChangeText={text => setAddress(text)}
          value={Address}
          placeholder={'Enter Full Address'}
          placeholderTextColor={'#EE848E'}
          style={{
            backgroundColor: 'white',
            borderRadius: 20,
            height: 50,
            marginTop: 12,
            padding: 10,
            fontSize: 16,
            color: '#EE848E',
          }}></TextInput>
      </View>
    );
  };
  const BloodtypeView = () => {
    return (
      <View style={{marginTop: 30}}>
        <Text
          style={{fontSize: 18, fontFamily: fonts.MEDIUM, color: '#DE0A1E'}}>
          {'Blood Type'}
        </Text>
        <View style={{flexDirection: 'row', marginTop: 12}}>
          <View style={{flexDirection: 'row', width: '25%'}}>
            <CheckBox
              hitSlop={{top: 10, bottom: 10, right: 10, left: 10}}
              value={Opos}
              onValueChange={() => {
                setBloodgrouptext('O+');
                setOpos(true);
                setOneg(false);
                setAbneg(false);
                setAbpos(false);
                setApos(false);
                setBpos(false);
                setAneg(false);
                setBneg(false);
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text style={{marginLeft: 10, color: '#DE0A1E', fontSize: 15}}>
              O+
            </Text>
          </View>

          <View style={{flexDirection: 'row', width: '25%'}}>
            <CheckBox
              hitSlop={{top: 10, bottom: 10, right: 10, left: 10}}
              value={Oneg}
              onValueChange={() => {
                setBloodgrouptext('O-');
                setOpos(false);
                setOneg(true);
                setAbneg(false);
                setAbpos(false);
                setApos(false);
                setBpos(false);
                setAneg(false);
                setBneg(false);
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text style={{marginLeft: 10, color: '#DE0A1E', fontSize: 15}}>
              {'O-'}
            </Text>
          </View>
          <View style={{flexDirection: 'row', width: '25%'}}>
            <CheckBox
              hitSlop={{top: 10, bottom: 10, right: 10, left: 10}}
              value={ABneg}
              onValueChange={() => {
                setBloodgrouptext('AB-');
                setOpos(false);
                setOneg(false);
                setAbneg(true);
                setAbpos(false);
                setApos(false);
                setBpos(false);
                setAneg(false);
                setApos(false);
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text style={{marginLeft: 10, color: '#DE0A1E', fontSize: 15}}>
              {'AB-'}
            </Text>
          </View>
          <View style={{flexDirection: 'row', width: '25%'}}>
            <CheckBox
              hitSlop={{top: 10, bottom: 10, right: 10, left: 10}}
              value={ABpos}
              onValueChange={() => {
                setBloodgrouptext('AB+');
                setOpos(false);
                setOneg(false);
                setAbneg(false);
                setAbpos(true);
                setApos(false);
                setBpos(false);
                setAneg(false);
                setBneg(false);
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text style={{marginLeft: 10, color: '#DE0A1E', fontSize: 15}}>
              {'AB+'}
            </Text>
          </View>
        </View>
        <View style={{flexDirection: 'row', marginTop: 12}}>
          <View style={{flexDirection: 'row', width: '25%'}}>
            <CheckBox
              hitSlop={{top: 10, bottom: 10, right: 10, left: 10}}
              value={Apos}
              onValueChange={() => {
                setBloodgrouptext('A+');
                setOpos(false);
                setOneg(false);
                setAbneg(false);
                setAbpos(false);
                setApos(true);
                setBpos(false);
                setAneg(false);
                setBneg(false);
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text style={{marginLeft: 10, color: '#DE0A1E', fontSize: 15}}>
              {'A+'}
            </Text>
          </View>

          <View style={{flexDirection: 'row', width: '25%'}}>
            <CheckBox
              hitSlop={{top: 10, bottom: 10, right: 10, left: 10}}
              value={Bpos}
              onValueChange={() => {
                setBloodgrouptext('B+');
                setOpos(false);
                setOneg(false);
                setAbneg(false);
                setAbpos(false);
                setApos(false);
                setBpos(true);
                setAneg(false);
                setBneg(false);
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text style={{marginLeft: 10, color: '#DE0A1E', fontSize: 15}}>
              {'B+'}
            </Text>
          </View>
          <View style={{flexDirection: 'row', width: '25%'}}>
            <CheckBox
              hitSlop={{top: 10, bottom: 10, right: 10, left: 10}}
              value={Aneg}
              onValueChange={() => {
                setBloodgrouptext('A-');
                setOpos(false);
                setOneg(false);
                setAbneg(false);
                setAbpos(false);
                setApos(false);
                setBpos(false);
                setAneg(true);
                setBneg(false);
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text style={{marginLeft: 10, color: '#DE0A1E', fontSize: 15}}>
              {'A-'}
            </Text>
          </View>
          <View style={{flexDirection: 'row', width: '25%'}}>
            <CheckBox
              hitSlop={{top: 10, bottom: 10, right: 10, left: 10}}
              value={Bneg}
              onValueChange={() => {
                setBloodgrouptext('B-');
                setOpos(false);
                setOneg(false);
                setAbneg(false);
                setAbpos(false);
                setApos(false);
                setBpos(false);
                setAneg(false);
                setBneg(true);
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text style={{marginLeft: 10, color: '#DE0A1E', fontSize: 15}}>
              {'B-'}
            </Text>
          </View>
        </View>
      </View>
    );
  };
  const contactView = () => {
    return (
      <View style={{marginTop: 12}}>
        <Text
          style={{fontSize: 14, fontFamily: fonts.MEDIUM, color: '#DE0A1E'}}>
          {'Preferred Means of Contact'}
        </Text>
        <View style={{flexDirection: 'row', marginTop: 12}}>
          <View style={{flexDirection: 'row', flex: 0.7}}>
            <CheckBox
              hitSlop={{top: 10, bottom: 10, right: 10, left: 10}}
              value={contactMobile}
              onValueChange={() => {
                setContactMobile(true);
              }}
              boxType={'square'}
              style={{height: 18, width: 18, borderColor: 'white'}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text style={{marginLeft: 10, color: '#DE0A1E', fontSize: 13}}>
              Mobile
            </Text>
          </View>

          <View style={{flexDirection: 'row', flex: 0.7}}>
            <CheckBox
              hitSlop={{top: 10, bottom: 10, right: 10, left: 10}}
              value={contactEmail}
              onValueChange={() => {
                setContactEmail;
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text style={{marginLeft: 10, color: '#DE0A1E', fontSize: 13}}>
              {'Email'}
            </Text>
          </View>
          <View style={{flexDirection: 'row', width: '33%'}}>
            <CheckBox
              hitSlop={{top: 10, bottom: 10, right: 10, left: 10}}
              value={contactSms}
              onValueChange={() => {
                setContactSms(true);
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text style={{marginLeft: 10, color: '#DE0A1E', fontSize: 13}}>
              {'SMS'}
            </Text>
          </View>
        </View>
      </View>
    );
  };
  const anydiseaseview = () => {
    return (
      <View style={{marginTop: 30}}>
        <Text
          style={{fontSize: 18, fontFamily: fonts.MEDIUM, color: '#DE0A1E'}}>
          {'Are you Diabetic, Hepatitis B or C?'}
        </Text>
        <View style={{flexDirection: 'row', marginTop: 12}}>
          <View style={{flexDirection: 'row', flex: 0.7}}>
            <CheckBox
              hitSlop={{top: 10, bottom: 10, right: 10, left: 10}}
              value={anydisease}
              onValueChange={() => {
                setAnydisease(true);
                setNodisease(false);
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text
              style={{
                marginLeft: 10,
                color: '#DE0A1E',
                fontSize: 15,
                alignSelf: 'center',
              }}>
              Yes
            </Text>
          </View>
          <View style={{flexDirection: 'row', marginLeft: 25}}>
            <CheckBox
              hitSlop={{top: 10, bottom: 10, right: 10, left: 10}}
              value={nodisease}
              onValueChange={() => {
                setAnydisease(false);
                setNodisease(true);
              }}
              boxType={'square'}
              style={{height: 20, width: 20}}
              lineWidth={1}
              hideBox={false}
              tintColors={'white'}
              onCheckColor={'white'}
              onFillColor={'#DE0A1E'}
              onTintColor={'#F4DCF8'}
              animationDuration={0.5}
              disabled={false}
              onAnimationType={'bounce'}
              offAnimationType={'stroke'}
            />
            <Text
              style={{
                marginLeft: 10,
                color: '#DE0A1E',
                fontSize: 15,
                alignSelf: 'center',
              }}>
              No
            </Text>
          </View>
        </View>
      </View>
    );
  };
  return (
    <View style={{flex: 1, backgroundColor: '#DE0A1E'}}>
      {/* <View style={{flexDirection: 'row', marginTop: 50}}> */}
      {/* <TouchableOpacity onPress={() => navigation.navigate('webview')}>
          <Image
            source={Images.landingscreen.donationdrive}
            style={{height: 20, width: 20, marginHorizontal: 20}}
          />
        </TouchableOpacity> */}
      <Text
        style={{
          color: 'white',
          alignSelf: 'center',
          marginTop: 50,
          fontFamily: fonts.MEDIUM,
          fontSize: 20,
        }}>
        {'  Blood Donor Registration'}
      </Text>
      {/* </View> */}
      {/* <Text
        style={{
          color: 'white',
          alignSelf: 'center',
          marginTop: 50,
          fontFamily: fonts.MEDIUM,
          fontSize: 20,
        }}>
        Blood Donor Registration
      </Text> */}
      <View
        style={{
          flex: 1,
          backgroundColor: 'white',
          marginTop: 30,
          borderTopLeftRadius: 25,
          borderTopRightRadius: 25,
          padding: 20,
        }}>
        {loadingIndicator && <SpinnerUi />}
        <Text
          style={{
            fontFamily: fonts.MEDIUM,
            fontStyle: 'italic',
            color: '#DE0A1E',
            marginBottom: 20,
          }}>
          "Every blood donor is a life saver. Join the effort with us and save
          lives."
        </Text>
        <ScrollView
          showsVerticalScrollIndicator={true}
          style={{
            flex: 1,
            borderRadius: 20,
            backgroundColor: '#F5F5F5',
            padding: 20,
          }}>
          <DatePicker
            modal
            mode="date"
            open={open}
            date={dob}
            maximumDate={new Date()}
            onConfirm={date => {
              setOpen(false);
              setDob(date);
            }}
            onCancel={() => {
              setOpen(false);
            }}
          />
          {NameView()}
          {dateandtextView('Date of Birth')}
          {anydiseaseview()}
          {textandcheckboxView('Gender')}

          {CitiesView()}
          {addressView()}
          {PhoneNumberView()}
          {EmailView()}
          {BloodtypeView()}
          {/* {contactView()} */}

          {bottomButtonView()}
          <View style={{marginBottom: 100}}></View>
        </ScrollView>
      </View>
    </View>
  );
};
export default Homepage;
