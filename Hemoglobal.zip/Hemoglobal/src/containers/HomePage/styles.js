import {StyleSheet, Dimensions} from 'react-native';
import fonts from '../../assets/fonts';
const {width, height} = Dimensions.get('window');

export const styles = StyleSheet.create({
  buttonContainer: {
    width: 300,
    height: 50,
    backgroundColor: '#DE0A1E',
    borderRadius: 40,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  imageSize: {width: 200, height: 200, alignSelf: 'center', marginTop: 300},
  buttontextStyle: {
    alignSelf: 'center',
    color: 'white',
    fontFamily: fonts.MEDIUM,
    fontSize: 20,
  },
  heading: {
    color: '#DE0A1E',
    fontSize: 30,
    justifyContent: 'center',
    fontFamily: fonts.BOLD,
  },
});
