import React, {useState} from 'react';
import {
  Modal,
  View,
  Dimensions,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
} from 'react-native';
import fonts from '../../assets/fonts';
import {apiKey} from '../../components/constants';
import CrossButton from '../../components/custombuttons';
import SpinnerUi from '../../components/SpinnerUi';
import {URLforemailverify} from '../../services/apiconfig';
import {styles} from '../findDonor/styles';
const {width, height} = Dimensions.get('window');
const Register = props => {
  const [email, setEmail] = useState('');
  const [loadingIndicator, setLoadingIndicator] = useState(false);
  const verifyemail = () => {
    if (email.trim().length == 0) {
      alert('Please Enter Email');
      return;
    }
    const emailRegex =
      /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    if (!email.match(emailRegex)) {
      alert('Please Enter Valid Email');
      return;
    }
    setLoadingIndicator(true);
    fetch(URLforemailverify, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
      },
      body: JSON.stringify({
        email: email,
        event_id: props?.eventId,
      }),
    })
      .then(response => response.json())
      .then(json => {
        const localList = json;

        const array1 = JSON.stringify(localList);
        const Obj = JSON.parse(array1);
        setLoadingIndicator(false);
        if (!Obj.status) {
          props?.callBack();
          //   alert(
          //     'We will redirect you to registration page. Please fill in the complete details to be a Donor. ',
          //   );
        } else {
          props?.close();
          alert(
            'We verified and your email is already registered as a Donor in our system. We have updated your registration for the selected camp.',
          );
        }
      })
      .catch(error => {
        console.error(error);
        setLoadingIndicator(false);
      });
  };
  return (
    <Modal animationType="fade" transparent={true} visible={true}>
      <View
        style={{
          flex: 1,
          backgroundColor: '#DE0A1E',
          flex: 1,
          alignContent: 'center',
          alignItems: 'center',
          opacity: 1,
          justifyContent: 'center',
        }}>
        <View
          style={{
            paddingTop: 10,
            paddingBottom: 20,
            paddingLeft: 20,
            paddingRight: 20,
            borderRadius: 20,
            width: Dimensions.get('screen').width - 40,
            backgroundColor: '#fff',
            opacity: 1,
          }}>
          <CrossButton
            hitSlop={{top: 20, left: 20, right: 20, bottom: 20}}
            onPress={() => props?.close()}
          />
          <Text
            style={{
              color: '#DE0A1E',
              fontSize: 18,
              fontFamily: fonts.SEMI_BOLD,
              alignSelf: 'center',
            }}>
            Enter Your Email Address
          </Text>
          {loadingIndicator && <SpinnerUi />}
          <TextInput
            onChangeText={text => setEmail(text)}
            value={email}
            placeholder={'Enter Email Address'}
            placeholderTextColor={'#EE848E'}
            style={{
              backgroundColor: 'white',
              borderColor: '#F5F5F5',
              borderRadius: 15,
              height: 30,
              borderWidth: 1,
              height: 50,
              marginTop: 12,
              padding: 10,
              color: '#EE848E',
            }}></TextInput>
          <View style={{marginTop: 30}}>
            <TouchableOpacity
              onPress={() => {
                verifyemail();
              }}
              style={{alignSelf: 'center'}}>
              <View style={styles.buttonContainer}>
                <Text style={styles.buttontextStyle}>{'Verify'}</Text>
              </View>
            </TouchableOpacity>
            <Text
              style={{
                color: 'grey',
                fontSize: 14,
                marginTop: 8,
                alignSelf: 'center',
                fontStyle: 'italic',
                fontFamily: fonts.MEDIUM,
              }}>
              (We will Check that if your email address is already registered)
            </Text>
          </View>
        </View>
      </View>
    </Modal>
  );
};
export default Register;
