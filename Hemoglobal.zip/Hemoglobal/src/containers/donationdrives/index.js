import moment from 'moment';
import React, {useEffect, useState} from 'react';
import {
  Text,
  View,
  FlatList,
  ImageBackground,
  TextInput,
  TouchableOpacity,
  Alert,
  ScrollView,
  Image,
} from 'react-native';
import fonts from '../../assets/fonts';
import Images from '../../assets/images';
import {apiKey} from '../../components/constants';
import SpinnerUi from '../../components/SpinnerUi';
import Navigation from '../../routes';
import {
  Urlforlistofdrives,
  URlforsearchDonationdrives,
} from '../../services/apiconfig';
import {styles} from '../findDonor/styles';
import Register from './customPopup';
const Data = [
  {
    id: 1,
  },
  {
    id: 1,
  },
  {
    id: 1,
  },
  {
    id: 1,
  },
  {
    id: 1,
  },
];
const Donationdrives = ({navigation, route}) => {
  const [loadingIndicator, setLoadingIndicator] = useState(false);
  const [location, setLocation] = useState('');
  const [driveslist, setDrivesList] = useState([]);
  const [showregisterPopup, setShowregisterPopup] = useState(false);
  const [selectedEmail, setSelectedEmail] = useState('');
  const [selectedEventId, setSelectedEventID] = useState('');
  useEffect(() => {
    setLocation('');
    getDonationdrivelist();
  }, []);

  const getDonationdrivelist = () => {
    setLoadingIndicator(true);
    fetch(Urlforlistofdrives, {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
      },
    })
      .then(response => response.json())
      .then(json => {
        const localList = json;
        const array1 = JSON.stringify(localList.events);
        const Obj = JSON.parse(array1);
        setDrivesList(Obj);
        setLoadingIndicator(false);
      })
      .catch(error => {
        console.error(error);
        setLoadingIndicator(false);
      });
  };
  const searchDonationDriveList = () => {
    setLoadingIndicator(true);
    fetch(URlforsearchDonationdrives + location, {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
      },
    })
      .then(response => response.json())
      .then(json => {
        const localList = json;
        const array1 = JSON.stringify(localList.events);
        const Obj = JSON.parse(array1);

        setDrivesList(Obj);
        setLoadingIndicator(false);
      })
      .catch(error => console.error(error));
  };

  const buttonView = () => {
    return (
      <View style={{marginTop: 30}}>
        <TouchableOpacity
          onPress={() => {
            searchDonationDriveList();
          }}
          style={{alignSelf: 'center'}}>
          <View style={styles.buttonContainer}>
            <Text style={styles.buttontextStyle}>{'Search Drive'}</Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  };
  const findDonorView = () => {
    return (
      <View
        style={{
          backgroundColor: 'white',
          padding: 20,
          height: 200,
          marginTop: 30,
          borderRadius: 20,
          marginBottom: -50,
        }}>
        <Text
          style={{color: '#201D1C', fontSize: 16, fontFamily: fonts.SEMI_BOLD}}>
          Find Donation drive
        </Text>
        <TextInput
          onChangeText={text => setLocationHandler(text)}
          value={location}
          placeholder={'Location'}
          style={{
            backgroundColor: 'white',
            borderRadius: 10,
            borderWidth: 1,
            borderColor: '#F5F5F5',
            height: 35,
            marginTop: 12,
            padding: 10,
            color: '#EE848E',
          }}></TextInput>

        {buttonView()}
      </View>
    );
  };
  const renderItems = item => {
    return (
      <View
        style={{
          marginTop: 20,

          borderWidth: 1,
          borderColor: '#F5F5F5',
          backgroundColor:
            moment(new Date()).format('YYYY/MM/DD') ==
            moment(item?.organized_date).format('YYYY/MM/DD')
              ? '#FFFFE6'
              : 'white',
          borderRadius: 20,
          flexDirection: 'row',
        }}>
        <ImageBackground
          source={Images.landingscreen.drop}
          style={{
            height: 150,
            width: 110,
            marginLeft: -40,
            marginTop: -45,
            justifyContent: 'center',
          }}>
          <Text
            style={{
              color: 'black',
              fontSize: 11,
              alignSelf: 'center',
              marginTop: 18,
              color: 'white',

              fontFamily: fonts.BOLD,
            }}>
            {moment(item?.organized_date).format('DD/MM')}
          </Text>
          <Text
            style={{
              color: 'black',
              fontSize: 11,
              alignSelf: 'center',

              color: 'white',

              fontFamily: fonts.BOLD,
            }}>
            {item?.organized_time}
          </Text>
        </ImageBackground>
        <View style={{marginTop: 10, marginLeft: -10, width: '90%'}}>
          <Text
            style={{
              color: '#201D1C',
              flex: 0.4,
              width: '90%',
              fontSize: 13,
              fontFamily: fonts.SEMI_BOLD,
            }}>
            {item?.blood_center +
              ' , ' +
              item?.address +
              ' ' +
              item?.city +
              ' , ' +
              item?.state}
          </Text>
          <Text
            style={{
              color: 'grey',
              fontSize: 14,
              marginTop: 6,
              fontFamily: fonts.SEMI_BOLD,
            }}>
            {'Contact: ' + item?.event_name + ' , ' + item?.phone}
          </Text>
          <View
            style={{
              marginTop: 10,
              marginBottom: 10,
              alignSelf: 'flex-end',
              marginRight: 40,
            }}>
            <TouchableOpacity
              onPress={() => {
                setShowregisterPopup(true);
                setSelectedEventID(item?.id);
                setSelectedEmail(item?.email);
              }}
              style={{alignSelf: 'center'}}>
              <View style={[styles.buttonContainer, {width: 100, height: 30}]}>
                <Text style={[styles.buttontextStyle, {fontSize: 15}]}>
                  {'Register '}
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  };
  const setLocationHandler = text => {
    setLocation(text);
  };
  const callbackHandler = () => {
    setShowregisterPopup(false);
    navigation.navigate('Donate Blood', {
      event_id: selectedEventId,
      email: selectedEmail,
    });
  };
  return (
    <View>
      <View style={{backgroundColor: '#DE0A1E', paddingHorizontal: 20}}>
        <Text
          style={{
            color: 'white',
            alignSelf: 'center',
            marginTop: 50,
            fontFamily: fonts.MEDIUM,
            fontSize: 20,
          }}>
          Blood Donation Drive
        </Text>
        {findDonorView(location)}
      </View>

      <ScrollView style={{marginTop: 60}}>
        {loadingIndicator && (
          <View style={{alignSelf: 'center', marginTop: 40, height: 100}}>
            <SpinnerUi />
          </View>
        )}
        {!loadingIndicator && driveslist?.length != 0 && (
          <FlatList
            data={driveslist}
            renderItem={({item, index}) => renderItems(item, index)}
            showsVerticalScrollIndicator={false}
            initialNumToRender={7}
            maxToRenderPerBatch={1}
            contentContainerStyle={{
              zIndex: -9999,
              padding: 20,
              marginTop: 5,
              paddingBottom: 400,
            }}
            onEndReachedThreshold={0.5}
          />
        )}
        {!loadingIndicator && driveslist.length == 0 && (
          <View style={{alignSelf: 'center', marginTop: 20}}>
            <Image
              source={Images.landingscreen.glass}
              style={{marginLeft: 20}}
            />
            <Text
              style={{
                fontSize: 18,
                marginTop: 20,
                fontStyle: 'italic',
                fontFamily: fonts.REGULAR,
                color: '#DE0A1E',
              }}>
              No Records Found
            </Text>
          </View>
        )}
        {showregisterPopup && (
          <Register
            close={() => setShowregisterPopup(false)}
            eventId={selectedEventId}
            email={selectedEmail}
            callBack={() => callbackHandler()}
          />
        )}
      </ScrollView>
    </View>
  );
};
export default Donationdrives;
