import React, {useState} from 'react';
import {
  Modal,
  View,
  Dimensions,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
} from 'react-native';
import fonts from '../../assets/fonts';
import {apiKey} from '../../components/constants';
import CrossButton from '../../components/custombuttons';
import {URLforemailverify, Urlformail} from '../../services/apiconfig';
import {styles} from '../findDonor/styles';
const {width, height} = Dimensions.get('window');
const Chat = props => {
  const [youremail, setyourEmail] = useState('');
  const [name, setName] = useState('');
  const toEmail = props?.toEmail;
  const blood_group = props?.blood_group;
  const [message, setMessage] = useState('');

  const toname = props?.toName;
  const EnterChat = () => {
    if (name.trim().length == 0) {
      alert('Please Enter Name');
      return;
    }
    if (youremail.trim().length == 0) {
      alert('Please Enter Email');
      return;
    }
    const emailRegex =
      /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    if (!youremail.match(emailRegex)) {
      alert('Please Enter Valid Email');
      return;
    }
    fetch(Urlformail, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
      },
      body: JSON.stringify({
        from_email: youremail,
        to_email: toEmail,
        message:
          'I am looking for ' +
          blood_group +
          ' Blood and found you as a Donor at Hemoglobe. Kindly reply back if the request looks fine to you.',
        from_name: name,
        to_name: toname,
      }),
    })
      .then(response => response.json())
      .then(json => {
        props?.close();
        alert('Email Sent Successfully');

        const localList = json;

        const array1 = JSON.stringify(localList);
        const Obj = JSON.parse(array1);
      })
      .catch(error => {
        console.error(error);
      });
  };
  return (
    <Modal animationType="fade" transparent={true} visible={true}>
      <View
        style={{
          flex: 1,
          backgroundColor: '#DE0A1E',
          flex: 1,
          alignContent: 'center',
          alignItems: 'center',
          opacity: 1,
          justifyContent: 'center',
        }}>
        <View
          style={{
            paddingTop: 10,
            paddingBottom: 20,
            paddingLeft: 20,
            paddingRight: 20,
            borderRadius: 20,
            width: Dimensions.get('screen').width - 40,
            backgroundColor: '#fff',
            opacity: 1,
          }}>
          <CrossButton
            hitSlop={{top: 20, left: 20, right: 20, bottom: 20}}
            onPress={() => props?.close()}
          />

          <Text
            style={{
              color: '#DE0A1E',
              fontSize: 18,
              fontFamily: fonts.SEMI_BOLD,
              alignSelf: 'center',
            }}>
            Connect with Donor
          </Text>

          <Text
            style={{
              fontSize: 18,
              fontFamily: fonts.MEDIUM,
              color: '#DE0A1E',
              marginTop: 20,
            }}>
            {'Enter Your Name'}
          </Text>
          <TextInput
            onChangeText={text => setName(text)}
            value={name}
            placeholder={'Enter Your Name'}
            placeholderTextColor={'#EE848E'}
            style={{
              backgroundColor: 'white',
              borderColor: '#F5F5F5',
              borderRadius: 15,
              height: 30,
              borderWidth: 1,
              height: 50,
              marginTop: 12,
              padding: 10,
              color: '#EE848E',
            }}></TextInput>
          <Text
            style={{
              fontSize: 18,
              fontFamily: fonts.MEDIUM,
              color: '#DE0A1E',
              marginTop: 20,
            }}>
            {'Enter Email Address'}
          </Text>
          <TextInput
            onChangeText={text => setyourEmail(text)}
            value={youremail}
            placeholder={'Enter Email Address'}
            placeholderTextColor={'#EE848E'}
            style={{
              backgroundColor: 'white',
              borderColor: '#F5F5F5',
              borderRadius: 15,
              height: 30,
              borderWidth: 1,
              height: 50,
              marginTop: 12,
              padding: 10,
              color: '#EE848E',
            }}></TextInput>
          <Text
            style={{
              fontSize: 18,
              fontFamily: fonts.MEDIUM,
              color: '#DE0A1E',
              marginTop: 20,
            }}>
            {'Message'}
          </Text>
          <View
            style={{
              backgroundColor: 'white',
              borderColor: '#F5F5F5',
              borderRadius: 15,
              height: 30,
              borderWidth: 1,
              height: 100,
              marginTop: 12,
              padding: 10,
            }}>
            <Text
              style={{
                color: '#EE848E',
                alignItems: 'center',
                fontFamily: fonts.MEDIUM,
                fontSize: 14,
              }}>
              {'I am looking for ' +
                blood_group +
                ' Blood and found you as a Donor at Hemoglobe. Kindly reply back if the request looks fine to you.'}
            </Text>
          </View>
          <View style={{marginTop: 30}}>
            <TouchableOpacity
              onPress={() => {
                EnterChat();
              }}
              style={{alignSelf: 'center'}}>
              <View style={styles.buttonContainer}>
                <Text style={styles.buttontextStyle}>{'Send'}</Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};
export default Chat;
