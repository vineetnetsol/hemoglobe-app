import moment from 'moment';
import React, {useEffect, useState} from 'react';
import {
  Alert,
  FlatList,
  Image,
  ImageBackground,
  ScrollView,
  Text,
  TextInput,
  Touchable,
  TouchableOpacity,
  View,
} from 'react-native';
import SelectDropdown from 'react-native-select-dropdown';
import fonts from '../../assets/fonts';
import Images from '../../assets/images';
import {apiKey} from '../../components/constants';
import SpinnerUi from '../../components/SpinnerUi';
import {Urlforlistofdonors} from '../../services/apiconfig';
import Chat from './custompopup';
import {styles} from './styles';
const Data = [
  {
    id: 1,
  },
  {
    id: 2,
  },
  {
    id: 3,
  },
  {
    id: 4,
  },
  {
    id: 5,
  },
];
const FindDonor = () => {
  const [loadingIndicator, setLoadingIndicator] = useState(false);
  const [selectedemail, setSelectedemail] = useState('');
  const [selectedname, setSelectedName] = useState('');
  const [selectedBloodgroup, setSelectedBloodgroup] = useState('');
  const [showChatpopup, setShowChatpopup] = useState(false);
  const [bloodgrouptext, setBloodgrouptext] = useState('');
  const [location, setLocation] = useState(' ');
  const [Abpos, setAbpos] = useState(false);
  const [Abneg, setAbneg] = useState(false);
  const [Apos, setApos] = useState(false);
  const [Aneg, setAneg] = useState(false);
  const [Bpos, setBpos] = useState(false);
  const [Bneg, setBneg] = useState(false);
  const [Opos, setOpos] = useState(false);
  const [Oneg, setOneg] = useState(false);

  const [donorsList, setDonorsList] = useState([]);
  const setLocationHandler = text => {
    setLocation(text);
  };

  useEffect(() => {
    getListofdonors();
  }, []);

  const getListofdonors = () => {
    setLoadingIndicator(true);
    fetch(Urlforlistofdonors, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
      },
      body: JSON.stringify({
        city: location,
        blood_group: bloodgrouptext,
      }),
    })
      .then(response => response.json())
      .then(json => {
        const localList = json;

        const array1 = JSON.stringify(localList.data.donors);

        const Obj = JSON.parse(array1);

        setDonorsList(Obj);
        setLoadingIndicator(false);
      })
      .catch(error => {
        console.error(error);
        setLoadingIndicator(false);
      });
  };
  const findDonorView = () => {
    return (
      <View
        style={{
          backgroundColor: 'white',
          padding: 20,
          height: 330,
          marginTop: 30,
          borderRadius: 20,
          marginBottom: -50,
        }}>
        <Text
          style={{color: '#201D1C', fontSize: 16, fontFamily: fonts.SEMI_BOLD}}>
          Search a Blood Donor
        </Text>
        <TextInput
          onChangeText={text => setLocationHandler(text)}
          value={location}
          placeholder={'Location'}
          style={{
            backgroundColor: 'white',
            borderRadius: 10,
            borderWidth: 1,
            borderColor: '#F5F5F5',
            height: 35,
            marginTop: 12,
            padding: 10,
            color: '#EE848E',
          }}></TextInput>
        <View style={{flexDirection: 'row', marginTop: 20}}>
          <TouchableOpacity
            style={{flex: 0.5}}
            onPress={() => {
              setBloodgrouptext('AB+');
              setAbpos(true);
              setAbneg(false);
              setBneg(false);
              setBpos(false);
              setApos(false);
              setAneg(false);
              setOneg(false);
              setOpos(false);
            }}>
            <View
              style={{
                height: 50,
                width: 50,
                borderWidth: 1,
                borderRadius: 20,
                borderColor: Abpos ? '#DE0A1E' : '#201D1C',
                justifyContent: 'center',
                backgroundColor: Abpos ? '#DE0A1E' : 'white',
              }}>
              <Text
                style={{
                  fontSize: 12,
                  alignSelf: 'center',
                  color: Abpos ? 'white' : '#201D1C',
                }}>
                AB+
              </Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={{flex: 0.5}}
            onPress={() => {
              setBloodgrouptext('AB-');
              setAbpos(false);
              setAbneg(true);
              setBneg(false);
              setBpos(false);
              setApos(false);
              setAneg(false);
              setOneg(false);
              setOpos(false);
            }}>
            <View
              style={{
                height: 50,
                width: 50,
                borderWidth: 1,
                borderRadius: 20,
                borderColor: Abneg ? '#DE0A1E' : '#201D1C',
                justifyContent: 'center',
                backgroundColor: Abneg ? '#DE0A1E' : 'white',
              }}>
              <Text
                style={{
                  fontSize: 12,
                  alignSelf: 'center',
                  color: Abneg ? 'white' : '#201D1C',
                }}>
                AB-
              </Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={{flex: 0.5}}
            onPress={() => {
              setBloodgrouptext('B+');
              setAbpos(false);
              setAbneg(false);
              setBneg(false);
              setBpos(true);
              setApos(false);
              setAneg(false);
              setOneg(false);
              setOpos(false);
            }}>
            <View
              style={{
                height: 50,
                width: 50,
                borderWidth: 1,
                borderRadius: 20,
                borderColor: Bpos ? '#DE0A1E' : '#201D1C',
                justifyContent: 'center',
                backgroundColor: Bpos ? '#DE0A1E' : 'white',
              }}>
              <Text
                style={{
                  fontSize: 12,
                  alignSelf: 'center',
                  color: Bpos ? 'white' : '#201D1C',
                }}>
                B+
              </Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={{flex: 0.5}}
            onPress={() => {
              setBloodgrouptext('B-');
              setAbpos(false);
              setAbneg(false);
              setBneg(true);
              setBpos(false);
              setApos(false);
              setAneg(false);
              setOneg(false);
              setOpos(false);
            }}>
            <View
              style={{
                height: 50,
                width: 50,
                borderWidth: 1,
                borderRadius: 20,
                borderColor: Bneg ? '#DE0A1E' : '#201D1C',
                justifyContent: 'center',
                backgroundColor: Bneg ? '#DE0A1E' : 'white',
              }}>
              <Text
                style={{
                  fontSize: 12,
                  alignSelf: 'center',
                  color: Bneg ? 'white' : '#201D1C',
                }}>
                B-
              </Text>
            </View>
          </TouchableOpacity>
        </View>
        <View style={{flexDirection: 'row', marginTop: 12}}>
          <TouchableOpacity
            style={{flex: 0.5}}
            onPress={() => {
              setBloodgrouptext('A+');
              setAbpos(false);
              setAbneg(false);
              setBneg(false);
              setBpos(false);
              setApos(true);
              setAneg(false);
              setOneg(false);
              setOpos(false);
            }}>
            <View
              style={{
                height: 50,
                width: 50,
                borderWidth: 1,
                borderRadius: 20,
                borderColor: Apos ? '#DE0A1E' : '#201D1C',
                justifyContent: 'center',
                backgroundColor: Apos ? '#DE0A1E' : 'white',
              }}>
              <Text
                style={{
                  fontSize: 12,
                  alignSelf: 'center',
                  color: Apos ? 'white' : '#201D1C',
                }}>
                A+
              </Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={{flex: 0.5}}
            onPress={() => {
              setBloodgrouptext('A-');
              setAbpos(false);
              setAbneg(false);
              setBneg(false);
              setBpos(false);
              setApos(false);
              setAneg(true);
              setOneg(false);
              setOpos(false);
            }}>
            <View
              style={{
                height: 50,
                width: 50,
                borderWidth: 1,
                borderRadius: 20,
                borderColor: Aneg ? '#DE0A1E' : '#201D1C',
                justifyContent: 'center',
                backgroundColor: Aneg ? '#DE0A1E' : 'white',
              }}>
              <Text
                style={{
                  fontSize: 12,
                  alignSelf: 'center',
                  color: Aneg ? 'white' : '#201D1C',
                }}>
                A-
              </Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={{flex: 0.5}}
            onPress={() => {
              setBloodgrouptext('O+');
              setAbpos(false);
              setAbneg(false);
              setBneg(false);
              setBpos(false);
              setApos(false);
              setAneg(false);
              setOneg(false);
              setOpos(true);
            }}>
            <View
              style={{
                height: 50,
                width: 50,
                borderWidth: 1,
                borderRadius: 20,
                borderColor: Opos ? '#DE0A1E' : '#201D1C',
                justifyContent: 'center',
                backgroundColor: Opos ? '#DE0A1E' : 'white',
              }}>
              <Text
                style={{
                  fontSize: 12,
                  alignSelf: 'center',
                  color: Opos ? 'white' : '#201D1C',
                }}>
                O+
              </Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={{flex: 0.5}}
            onPress={() => {
              setAbpos(false);
              setBloodgrouptext('O-');
              setAbneg(false);
              setBneg(false);
              setBpos(false);
              setApos(false);
              setAneg(false);
              setOneg(true);
              setOpos(false);
            }}>
            <View
              style={{
                height: 50,
                width: 50,
                borderWidth: 1,
                borderRadius: 20,
                borderColor: Oneg ? '#DE0A1E' : '#201D1C',
                justifyContent: 'center',
                backgroundColor: Oneg ? '#DE0A1E' : 'white',
              }}>
              <Text
                style={{
                  fontSize: 12,
                  alignSelf: 'center',
                  color: Oneg ? 'white' : '#201D1C',
                }}>
                O-
              </Text>
            </View>
          </TouchableOpacity>
        </View>
        {buttonView()}
      </View>
    );
  };
  const buttonView = () => {
    return (
      <View style={{marginTop: 30}}>
        <TouchableOpacity
          onPress={() => {
            getListofdonors();
          }}
          style={{alignSelf: 'center'}}>
          <View style={styles.buttonContainer}>
            <Text style={styles.buttontextStyle}>{'Search Donor'}</Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  };
  const renderItems = item => {
    return (
      <View
        style={{
          marginTop: 10,

          borderWidth: 1,
          borderColor: '#F5F5F5',
          backgroundColor: item?.is_matching ?? 1 ? '#FFFFE6' : 'white',
          borderRadius: 20,
          flexDirection: 'row',
        }}>
        <ImageBackground
          source={Images.landingscreen.drop}
          style={{
            height: 150,
            width: 110,
            marginLeft: -40,
            marginTop: -55,
            justifyContent: 'center',
          }}>
          <Text
            style={{
              color: 'black',
              fontSize: 14,
              alignSelf: 'center',
              marginTop: 16,
              color: 'white',
              fontFamily: fonts.BOLD,
            }}>
            {item?.blood_group}
          </Text>
        </ImageBackground>
        <View style={{marginTop: 10, width: '90%'}}>
          <View style={{flexDirection: 'row'}}>
            <Text
              style={{
                color: '#201D1C',
                fontSize: 14,
                flex: 0.8,
                fontFamily: fonts.SEMI_BOLD,
              }}>
              {item?.name}
            </Text>
            <Text
              style={{
                color: 'grey',
                fontFamily: fonts.SEMI_BOLD,
                fontSize: 14,
                alignSelf: 'flex-end',
              }}>
              {'' + moment(item?.dob).format('YYYY/MM/DD')}
            </Text>
          </View>

          <Text
            style={{
              color: '#201D1C',
              fontSize: 14,
              fontFamily: fonts.SEMI_BOLD,
              marginTop: 6,
              width: '90%',
            }}>
            {item?.address + ' , ' + item?.city + ' , ' + item?.state}
          </Text>
          <View style={{flexDirection: 'row', marginTop: 6}}>
            {/* <Image
              source={Images.landingscreen.phone}
              style={{height: 30, width: 30, alignSelf: 'center'}}
            /> */}
            <Text
              style={{
                color: 'grey',
                fontSize: 14,
                alignSelf: 'center',
                fontFamily: fonts.SEMI_BOLD,
              }}>
              {'XXXXX' + (item?.phone).substring(5)}
            </Text>
          </View>
          <View style={{flexDirection: 'row'}}>
            {/* <Image
              source={Images.landingscreen.email}
              style={{
                height: 18,
                width: 18,
                marginLeft: 6,

                alignSelf: 'center',
              }}
            /> */}
            <Text
              style={{
                color: 'grey',
                fontSize: 14,
                alignSelf: 'center',
                fontFamily: fonts.SEMI_BOLD,
                width: '90%',
              }}>
              {'XXXXX' + (item?.email).substring(5)}
            </Text>
          </View>

          <View
            style={{
              marginTop: 10,
              marginBottom: 10,
              alignSelf: 'flex-end',
              marginRight: 40,
            }}>
            <TouchableOpacity
              onPress={() => {
                setShowChatpopup(true);
                setSelectedBloodgroup(item?.blood_group);
                setSelectedemail(item?.email);
                setSelectedName(item?.name);
              }}
              style={{alignSelf: 'center'}}>
              <View style={[styles.buttonContainer, {width: 100, height: 30}]}>
                <Text style={[styles.buttontextStyle, {fontSize: 15}]}>
                  {'Message'}
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  };
  return (
    <View>
      <View style={{backgroundColor: '#DE0A1E', paddingHorizontal: 20}}>
        <Text
          style={{
            color: 'white',
            alignSelf: 'center',
            marginTop: 50,
            fontFamily: fonts.MEDIUM,
            fontSize: 20,
          }}>
          Search a Blood Donor
        </Text>
        {findDonorView()}
      </View>
      {/* <Text
        style={{
          color: '#201D1C',
          fontSize: 16,
          fontFamily: fonts.SEMI_BOLD,
          paddingHorizontal: 20,
          marginTop: 70,
        }}>
        Recent Blood Donors
      </Text> */}

      <ScrollView style={{marginTop: 55}}>
        {loadingIndicator && (
          <View style={{alignSelf: 'center', marginTop: 40, height: 100}}>
            <SpinnerUi />
          </View>
        )}
        {!loadingIndicator && donorsList?.length != 0 && (
          <FlatList
            data={donorsList}
            renderItem={({item, index}) => renderItems(item, index)}
            showsVerticalScrollIndicator={false}
            initialNumToRender={7}
            maxToRenderPerBatch={1}
            contentContainerStyle={{
              zIndex: -9999,
              padding: 20,
              paddingBottom: 500,
            }}
            onEndReachedThreshold={0.5}
          />
        )}
        {!loadingIndicator && donorsList.length == 0 && (
          <View style={{alignSelf: 'center', marginTop: 20}}>
            <Image
              source={Images.landingscreen.glass}
              style={{marginLeft: 20}}
            />
            <Text
              style={{
                fontSize: 18,
                marginTop: 20,
                fontStyle: 'italic',
                fontFamily: fonts.REGULAR,
                color: '#DE0A1E',
              }}>
              No Records Found
            </Text>
          </View>
        )}

        {showChatpopup && (
          <Chat
            close={() => setShowChatpopup(false)}
            blood_group={selectedBloodgroup}
            toEmail={selectedemail}
            toName={selectedname}
          />
        )}
      </ScrollView>
    </View>
  );
};

export default FindDonor;
