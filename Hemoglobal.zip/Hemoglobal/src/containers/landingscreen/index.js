import React from 'react';
import {Image, Text, TouchableOpacity, View} from 'react-native';
import fonts from '../../assets/fonts';
import Images from '../../assets/images';
import {styles} from './styles';
const LandingScreen = ({navigation, route}) => {
  const ButtonsView = text => {
    return (
      <View style={{}}>
        <TouchableOpacity
          onPress={() => {
            navigation.navigate('Homescreen');
          }}>
          <View style={styles.buttonContainer}>
            <Text style={styles.buttontextStyle}>Become a Hero</Text>
          </View>
        </TouchableOpacity>
        {/* <TouchableOpacity
          onPress={() => {
            navigation.navigate('webview');
          }}>
          <View style={[styles.buttonContainer, {marginTop: 20}]}>
            <Text style={styles.buttontextStyle}>About us </Text>
          </View>
        </TouchableOpacity> */}
      </View>
    );
  };
  return (
    <View style={{backgroundColor: 'white', flex: 1, alignItems: 'center'}}>
      <Image
        source={Images.landingscreen.step1}
        style={styles.imageSize}></Image>
      <View style={{marginTop: 30, padding: 20, justifyContent: 'center'}}>
        <Text style={styles.heading}>
          Donating Blood is the real act of humanity.
        </Text>
      </View>

      {ButtonsView()}
    </View>
  );
};

export default LandingScreen;
