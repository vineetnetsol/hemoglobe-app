import React from 'react';
import {View} from 'react-native';
import WebView from 'react-native-webview';
import {apiKey} from '../../components/constants';

const Webview = () => {
  return <WebView source={{html: ''}} />;
};

export default Webview;
