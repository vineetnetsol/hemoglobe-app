import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { StackNavigation } from "./stacks";






const stack = createStackNavigator();
const Navigation = () => {
    return (
        <NavigationContainer>
          <StackNavigation/>
        </NavigationContainer>
    )
}

export default Navigation;