import {createStackNavigator} from '@react-navigation/stack';
import React from 'react';
import FindDonor from '../containers/findDonor';
import Homepage from '../containers/HomePage';
import LandingScreen from '../containers/landingscreen';
import WebView from '../containers/webview';
import {TabNavigation} from './tabnavigation';

const Stack = createStackNavigator();

export const StackNavigation = () => {
  return (
    <Stack.Navigator
      initialRouteName="Landingscreen"
      screenOptions={{
        headerShown: false,
      }}>
      <Stack.Screen component={LandingScreen} name={'LandingScreen'} />
      <Stack.Screen component={TabNavigation} name={'Homescreen'} />
      <Stack.Screen component={FindDonor} name={'finddonor'} />
      <Stack.Screen component={WebView} name={'webview'} />
    </Stack.Navigator>
  );
};
