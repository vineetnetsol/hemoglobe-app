import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {Image} from 'react-native';
import fonts from '../assets/fonts';
import Images from '../assets/images';
import Donationdrives from '../containers/donationdrives';
import FindDonor from '../containers/findDonor';
import Homepage from '../containers/HomePage';

const Tab = createBottomTabNavigator();
export function TabNavigation(props) {
  const tabBarOptions = {
    tabBarActiveTintColor: '#DE0A1E',
    tabBarInactiveTintColor: '#Ee848E',
    tabBarLabelStyle: {
      fontSize: 9,
      fontFamily: fonts.MEDIUM,
    },
    tabBarStyle: {
      backgroundColor: 'white',
    },
    tabBarHideOnKeyboard: true,
    adaptive: false,
    headerShown: false,
  };
  return (
    <Tab.Navigator
      screenOptions={tabBarOptions}
      initialRouteName={'Homescreen'}>
      <Tab.Screen
        name={'Donate Blood'}
        component={Homepage}
        options={{
          tabBarIcon: ({color, size}) => (
            <Image
              resizeMode="contain"
              source={Images.landingscreen.donate}
              style={{height: 30, width: 30}}
            />
          ),
        }}
      />
      <Tab.Screen
        name={'Donation Drives'}
        component={Donationdrives}
        options={{
          tabBarIcon: ({color, size}) => (
            <Image
              resizeMode="contain"
              source={Images.landingscreen.donationdrive}
              style={{height: 48, width: 65}}
            />
          ),
        }}
      />
      <Tab.Screen
        name={'Find Donor'}
        component={FindDonor}
        options={{
          tabBarIcon: ({color, size}) => (
            <Image
              resizeMode="contain"
              source={Images.landingscreen.finddonor}
              style={{height: 35, width: 46}}
            />
          ),
        }}
      />
    </Tab.Navigator>
  );
}
