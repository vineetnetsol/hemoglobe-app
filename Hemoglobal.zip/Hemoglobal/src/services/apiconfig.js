export const UrlforStates =
  'https://xes7vwbx99.execute-api.ap-south-1.amazonaws.com/prod/states';
export const Urlforcities =
  'https://xes7vwbx99.execute-api.ap-south-1.amazonaws.com/prod/cities/n/';
export const Urlforregisterdonor =
  'https://xes7vwbx99.execute-api.ap-south-1.amazonaws.com/prod/donor';
export const Urlforlistofdonors =
  'https://xes7vwbx99.execute-api.ap-south-1.amazonaws.com/prod/search/donor';
export const Urlforlistofdrives =
  'https://xes7vwbx99.execute-api.ap-south-1.amazonaws.com/prod/list-camps';
export const URlforsearchDonationdrives =
  'https://xes7vwbx99.execute-api.ap-south-1.amazonaws.com/prod/list-camps?name=';
export const URLforemailverify =
  'https://xes7vwbx99.execute-api.ap-south-1.amazonaws.com/prod/donors/check-email';
export const Urlformail =
  'https://xes7vwbx99.execute-api.ap-south-1.amazonaws.com/prod/donor/mail';
